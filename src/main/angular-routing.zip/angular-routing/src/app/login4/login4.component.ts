import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login4',
  templateUrl: './login4.component.html',
  styleUrls: ['./login4.component.css']
})
export class Login4Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
