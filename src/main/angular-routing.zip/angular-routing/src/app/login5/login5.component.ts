import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login5',
  templateUrl: './login5.component.html',
  styleUrls: ['./login5.component.css']
})
export class Login5Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
